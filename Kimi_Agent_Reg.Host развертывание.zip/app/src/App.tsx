import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import Layout from '@/components/layout/Layout';
import Home from '@/pages/Home';
import Services from '@/pages/Services';
import ServiceDetail from '@/pages/ServiceDetail';
import Prices from '@/pages/Prices';
import About from '@/pages/About';
import Reviews from '@/pages/Reviews';
import Contacts from '@/pages/Contacts';
import Booking from '@/pages/Booking';
import NotFound from '@/pages/NotFound';

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="motors-theme">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="uslugi" element={<Services />} />
            <Route path="uslugi/:slug" element={<ServiceDetail />} />
            <Route path="ceny" element={<Prices />} />
            <Route path="o-kompanii" element={<About />} />
            <Route path="otzyvy" element={<Reviews />} />
            <Route path="kontakty" element={<Contacts />} />
            <Route path="zapis" element={<Booking />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;
