import { Link } from 'react-router-dom';
import { Wrench, Phone, MapPin, Clock, ExternalLink } from 'lucide-react';

const serviceLinks = [
  { path: '/uslugi/remont-dvigateley', label: 'Ремонт двигателей' },
  { path: '/uslugi/remont-toplivnoy-sistemy', label: 'Ремонт топливной системы' },
  { path: '/uslugi/diagnostika', label: 'Диагностика' },
  { path: '/uslugi/to', label: 'Техническое обслуживание' },
  { path: '/uslugi/remont-hodovoy', label: 'Ремонт ходовой' },
];

const companyLinks = [
  { path: '/o-kompanii', label: 'О компании' },
  { path: '/ceny', label: 'Цены' },
  { path: '/otzyvy', label: 'Отзывы' },
  { path: '/kontakty', label: 'Контакты' },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary">
                <Wrench className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">МОТОРС</span>
                <span className="text-xs text-muted-foreground leading-tight">Грузовой сервис</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground mb-4">
              Профессиональный ремонт и обслуживание грузовых автомобилей в Тюмени. 
              Ремонт двигателей, топливной системы, диагностика.
            </p>
            <div className="flex flex-col gap-2">
              <a
                href="tel:+79222652920"
                className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors"
              >
                <Phone className="h-4 w-4" />
                +7 (922) 265-29-20
              </a>
              <a
                href="tel:+73452981270"
                className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors"
              >
                <Phone className="h-4 w-4" />
                +7 (3452) 98-12-70
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">Услуги</h3>
            <ul className="space-y-2">
              {serviceLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Компания</h3>
            <ul className="space-y-2">
              {companyLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4">Мы на карте</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>г. Тюмень, ул. Щербакова, 170 ст6</span>
              </div>
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Пн-Пт: 09:00-17:00</span>
              </div>
              <div className="flex gap-3 mt-4">
                <a
                  href="https://yandex.ru/maps/-/CDXW5Z~n"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#FFD700] text-black rounded-md hover:bg-[#FFC700] transition-colors"
                >
                  Яндекс Карты
                  <ExternalLink className="h-3 w-3" />
                </a>
                <a
                  href="https://2gis.ru/tyumen/firm/1830115629869353"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#7CB342] text-white rounded-md hover:bg-[#6A9E3A] transition-colors"
                >
                  2GIS
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © {currentYear} Моторс. Все права защищены.
            </p>
            <div className="flex gap-4 text-sm">
              <Link to="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                Политика конфиденциальности
              </Link>
              <Link to="/consent" className="text-muted-foreground hover:text-foreground transition-colors">
                Согласие на обработку данных
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
