import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '@/components/theme-provider';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Phone, Menu, Sun, Moon, Wrench } from 'lucide-react';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/ceny', label: 'Цены' },
  { path: '/o-kompanii', label: 'О компании' },
  { path: '/otzyvy', label: 'Отзывы' },
  { path: '/kontakty', label: 'Контакты' },
];

export default function Header() {
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary">
              <Wrench className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-tight">МОТОРС</span>
              <span className="text-xs text-muted-foreground leading-tight">Грузовой сервис</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  isActive(item.path)
                    ? 'bg-primary/10 text-primary'
                    : 'text-foreground/80 hover:text-foreground hover:bg-accent'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="hidden sm:flex"
              aria-label="Переключить тему"
            >
              {theme === 'dark' ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>

            {/* Phone */}
            <a
              href="tel:+79222652920"
              className="hidden md:flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors"
            >
              <Phone className="h-4 w-4" />
              +7 (922) 265-29-20
            </a>

            {/* CTA Button */}
            <Link to="/zapis" className="hidden sm:block">
              <Button size="sm">Записаться</Button>
            </Link>

            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" aria-label="Меню">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[280px]">
                <div className="flex flex-col gap-6 mt-6">
                  <Link
                    to="/"
                    className="flex items-center gap-2"
                    onClick={() => setIsOpen(false)}
                  >
                    <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary">
                      <Wrench className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-lg font-bold leading-tight">МОТОРС</span>
                      <span className="text-xs text-muted-foreground leading-tight">Грузовой сервис</span>
                    </div>
                  </Link>

                  <nav className="flex flex-col gap-2">
                    {navItems.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setIsOpen(false)}
                        className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                          isActive(item.path)
                            ? 'bg-primary/10 text-primary'
                            : 'text-foreground/80 hover:text-foreground hover:bg-accent'
                        }`}
                      >
                        {item.label}
                      </Link>
                    ))}
                  </nav>

                  <div className="flex flex-col gap-3">
                    <a
                      href="tel:+79222652920"
                      className="flex items-center gap-2 text-sm font-medium"
                    >
                      <Phone className="h-4 w-4" />
                      +7 (922) 265-29-20
                    </a>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={toggleTheme}
                      className="justify-start"
                    >
                      {theme === 'dark' ? (
                        <>
                          <Sun className="h-4 w-4 mr-2" />
                          Светлая тема
                        </>
                      ) : (
                        <>
                          <Moon className="h-4 w-4 mr-2" />
                          Тёмная тема
                        </>
                      )}
                    </Button>
                    <Link to="/zapis" onClick={() => setIsOpen(false)}>
                      <Button className="w-full">Записаться</Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
