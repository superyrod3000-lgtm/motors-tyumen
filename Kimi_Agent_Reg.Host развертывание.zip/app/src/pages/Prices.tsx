import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { Phone, Calendar, Info } from 'lucide-react';

interface PriceItem {
  name: string;
  price: string;
  note?: string;
}

interface PriceCategory {
  title: string;
  items: PriceItem[];
}

const priceData: PriceCategory[] = [
  {
    title: 'Ремонт двигателей',
    items: [
      { name: 'Диагностика двигателя', price: 'от 2 500 ₽' },
      { name: 'Текущий ремонт двигателя', price: 'от 25 000 ₽' },
      { name: 'Капитальный ремонт двигателя', price: 'от 150 000 ₽' },
      { name: 'Замена поршневой группы', price: 'от 80 000 ₽' },
      { name: 'Ремонт ГБЦ', price: 'от 35 000 ₽' },
      { name: 'Замена ремня ГРМ', price: 'от 8 000 ₽' },
      { name: 'Замена цепи ГРМ', price: 'от 25 000 ₽' },
      { name: 'Замена прокладки ГБЦ', price: 'от 15 000 ₽' },
    ],
  },
  {
    title: 'Ремонт топливной системы',
    items: [
      { name: 'Диагностика топливной системы', price: 'от 2 500 ₽' },
      { name: 'Ремонт ТНВД', price: 'от 25 000 ₽' },
      { name: 'Ремонт форсунки', price: 'от 5 000 ₽' },
      { name: 'Ремонт насос-форсунки', price: 'от 8 000 ₽' },
      { name: 'Замена топливного фильтра', price: 'от 1 500 ₽' },
      { name: 'Чистка топливной системы', price: 'от 5 000 ₽' },
      { name: 'Настройка ТНВД на стенде', price: 'от 10 000 ₽' },
    ],
  },
  {
    title: 'Диагностика',
    items: [
      { name: 'Компьютерная диагностика', price: 'от 2 500 ₽' },
      { name: 'Диагностика двигателя', price: 'от 2 500 ₽' },
      { name: 'Диагностика трансмиссии', price: 'от 3 000 ₽' },
      { name: 'Диагностика тормозной системы', price: 'от 1 500 ₽' },
      { name: 'Диагностика электросистемы', price: 'от 2 000 ₽' },
      { name: 'Комплексная диагностика', price: 'от 8 000 ₽' },
    ],
  },
  {
    title: 'Ремонт ходовой части',
    items: [
      { name: 'Диагностика ходовой части', price: 'от 1 500 ₽' },
      { name: 'Замена амортизатора', price: 'от 3 000 ₽' },
      { name: 'Замена пружины', price: 'от 2 500 ₽' },
      { name: 'Замена сайлентблока', price: 'от 2 000 ₽' },
      { name: 'Замена шаровой опоры', price: 'от 2 500 ₽' },
      { name: 'Замена рулевого наконечника', price: 'от 2 000 ₽' },
      { name: 'Замена тормозных колодок', price: 'от 3 000 ₽' },
      { name: 'Развал-схождение', price: 'от 5 000 ₽' },
    ],
  },
  {
    title: 'Ремонт автоэлектрики',
    items: [
      { name: 'Диагностика электросистемы', price: 'от 2 000 ₽' },
      { name: 'Ремонт генератора', price: 'от 5 000 ₽' },
      { name: 'Ремонт стартера', price: 'от 4 000 ₽' },
      { name: 'Замена аккумулятора', price: 'от 1 000 ₽' },
      { name: 'Ремонт проводки', price: 'от 3 000 ₽' },
      { name: 'Установка доп. оборудования', price: 'от 2 500 ₽' },
    ],
  },
  {
    title: 'Техническое обслуживание',
    items: [
      { name: 'ТО-1 (10 000 км)', price: 'от 5 000 ₽' },
      { name: 'ТО-2 (20 000 км)', price: 'от 8 000 ₽' },
      { name: 'Замена масла в двигателе', price: 'от 2 500 ₽' },
      { name: 'Замена масляного фильтра', price: 'от 500 ₽' },
      { name: 'Замена воздушного фильтра', price: 'от 1 000 ₽' },
      { name: 'Замена топливного фильтра', price: 'от 1 500 ₽' },
      { name: 'Замена масла в КПП', price: 'от 3 000 ₽' },
      { name: 'Замена масла в мостах', price: 'от 3 000 ₽' },
    ],
  },
];

export default function Prices() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              Цены
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Прайс-лист на услуги
            </h1>
            <p className="text-lg text-muted-foreground">
              Актуальные цены на все виды работ. Окончательная стоимость 
              определяется после диагностики и согласовывается с клиентом.
            </p>
          </div>
        </div>
      </section>

      {/* Price List */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {priceData.map((category, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {category.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex justify-between items-start gap-4 py-2 border-b last:border-0"
                      >
                        <div className="flex-1">
                          <span className="text-sm">{item.name}</span>
                          {item.note && (
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {item.note}
                            </p>
                          )}
                        </div>
                        <span className="font-semibold text-primary whitespace-nowrap">
                          {item.price}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Info */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Info className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Важная информация</h3>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>
                        • Указанные цены являются ориентировочными и могут 
                        варьироваться в зависимости от марки автомобиля и 
                        сложности работ
                      </li>
                      <li>
                        • Окончательная стоимость определяется после диагностики 
                        и согласовывается с клиентом перед началом работ
                      </li>
                      <li>
                        • В стоимость не включены запчасти и расходные материалы
                      </li>
                      <li>
                        • Предоставляем скидки при комплексном ремонте и 
                        для постоянных клиентов
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-2xl p-8 lg:p-12 text-primary-foreground">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">
                Уточнить стоимость ремонта
              </h2>
              <p className="text-primary-foreground/80 mb-8">
                Свяжитесь с нами для получения точной сметы ремонта 
                вашего автомобиля
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/zapis">
                  <Button variant="secondary" size="lg" className="gap-2">
                    <Calendar className="h-4 w-4" />
                    Записаться на диагностику
                  </Button>
                </Link>
                <a href="tel:+79222652920">
                  <Button
                    variant="outline"
                    size="lg"
                    className="gap-2 border-primary-foreground/30 hover:bg-primary-foreground/10"
                  >
                    <Phone className="h-4 w-4" />
                    Позвонить
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
