import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { reviews } from '@/data/services';
import { Star, MessageSquare, Calendar } from 'lucide-react';

export default function ReviewsPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              Отзывы
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Отзывы наших клиентов
            </h1>
            <p className="text-lg text-muted-foreground">
              Узнайте, что говорят о нас владельцы грузовых автомобилей, 
              которые уже воспользовались нашими услугами
            </p>
          </div>
        </div>
      </section>

      {/* Reviews Stats */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                4.9
              </div>
              <div className="flex justify-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className="h-5 w-5 fill-primary text-primary"
                  />
                ))}
              </div>
              <div className="text-muted-foreground">Средняя оценка</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                150+
              </div>
              <div className="text-muted-foreground">Отзывов</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                95%
              </div>
              <div className="text-muted-foreground">Рекомендуют нас</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                50+
              </div>
              <div className="text-muted-foreground">Постоянных клиентов</div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review) => (
              <Card key={review.id} className="h-full">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < review.rating
                            ? 'fill-primary text-primary'
                            : 'text-muted-foreground'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-6">{review.text}</p>
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div>
                      <div className="font-semibold">{review.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {review.vehicle}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      {new Date(review.date).toLocaleDateString('ru-RU')}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Add Review CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-2xl p-8 lg:p-12 text-primary-foreground">
            <div className="max-w-3xl mx-auto text-center">
              <div className="w-16 h-16 rounded-full bg-primary-foreground/20 flex items-center justify-center mx-auto mb-6">
                <MessageSquare className="h-8 w-8" />
              </div>
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">
                Оставьте свой отзыв
              </h2>
              <p className="text-primary-foreground/80 mb-8">
                Ваше мнение важно для нас! Поделитесь опытом работы с нашим сервисом 
                — это поможет другим клиентам сделать правильный выбор
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://yandex.ru/maps/-/CDXW5Z~n"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="secondary" size="lg">
                    Оставить отзыв на Яндекс.Картах
                  </Button>
                </a>
                <a
                  href="https://2gis.ru/tyumen/firm/1830115629869353"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-primary-foreground/30 hover:bg-primary-foreground/10"
                  >
                    Оставить отзыв на 2GIS
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
