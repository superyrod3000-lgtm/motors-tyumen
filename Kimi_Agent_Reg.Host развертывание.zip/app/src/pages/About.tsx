import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Users, Wrench, Calendar, Award } from 'lucide-react';

const stats = [
  { value: '15+', label: 'лет опыта' },
  { value: '5000+', label: 'отремонтированных авто' },
  { value: '50+', label: 'постоянных клиентов' },
  { value: '12', label: 'месяцев гарантии' },
];

const advantages = [
  {
    icon: Wrench,
    title: 'Современное оборудование',
    description: 'Используем профессиональное диагностическое и ремонтное оборудование ведущих мировых производителей.',
  },
  {
    icon: Users,
    title: 'Опытные специалисты',
    description: 'Наши мастера имеют многолетний опыт работы с грузовой техникой различных марок.',
  },
  {
    icon: CheckCircle,
    title: 'Качественные запчасти',
    description: 'Работаем только с проверенными поставщиками оригинальных и качественных аналоговых запчастей.',
  },
  {
    icon: Award,
    title: 'Гарантия на работы',
    description: 'Предоставляем гарантию на все виды выполненных работ до 12 месяцев.',
  },
];

export default function About() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              О компании
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Автосервис «Моторс»
            </h1>
            <p className="text-lg text-muted-foreground">
              Профессиональный ремонт и обслуживание грузовых автомобилей 
              в Тюмени с 2009 года
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">О нашей компании</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Автосервис «Моторс» — это специализированный сервис по ремонту 
                  и обслуживанию грузовых автомобилей в Тюмени. Мы работаем с 2009 
                  года и за это время зарекомендовали себя как надёжный партнёр 
                  для владельцев грузовой техники.
                </p>
                <p>
                  Наша специализация — ремонт двигателей и топливной системы 
                  грузовых автомобилей. Мы работаем со всеми марками отечественной 
                  и китайской техники: КамАЗ, Урал, ГАЗ, УАЗ, FAW, Howo, Shacman, 
                  Foton и другими.
                </p>
                <p>
                  В нашем распоряжении современное диагностическое и ремонтное 
                  оборудование, которое позволяет быстро и точно определять 
                  неисправности и выполнять ремонт любой сложности.
                </p>
                <p>
                  Мы ценим каждого клиента и стремимся к долгосрочному сотрудничеству. 
                  Именно поэтому предоставляем гарантию на все виды работ и используем 
                  только качественные запчасти.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl transform rotate-3" />
              <div className="relative bg-muted rounded-3xl overflow-hidden aspect-[4/3] flex items-center justify-center">
                <Wrench className="h-32 w-32 text-primary/30" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Advantages */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Наши преимущества</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Почему владельцы грузовых автомобилей выбирают наш сервис
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {advantages.map((advantage, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <advantage.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{advantage.title}</h3>
                  <p className="text-muted-foreground">{advantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Equipment */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl transform -rotate-3" />
              <div className="relative bg-muted rounded-3xl overflow-hidden aspect-[4/3] flex items-center justify-center">
                <Calendar className="h-32 w-32 text-primary/30" />
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl font-bold mb-6">Наше оборудование</h2>
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  Для выполнения качественного ремонта мы используем современное 
                  оборудование ведущих мировых производителей:
                </p>
                <ul className="space-y-3">
                  {[
                    'Компьютерные диагностические сканеры для всех марок грузовых автомобилей',
                    'Стенды для настройки и проверки ТНВД и форсунок',
                    'Гидравлические прессы и подъёмное оборудование',
                    'Специализированный инструмент для ремонта двигателей',
                    'Оборудование для развал-схождения',
                    'Сварочное оборудование',
                  ].map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brands */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Марки автомобилей, которые мы обслуживаем</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Работаем со всеми марками отечественных и зарубежных грузовых автомобилей
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            {[
              'КамАЗ',
              'Урал',
              'ГАЗ',
              'УАЗ',
              'FAW',
              'Howo',
              'Shacman',
              'Foton',
              'Dongfeng',
              'JAC',
              'JMC',
              'Isuzu',
              'Hino',
              'MAN',
              'DAF',
              'Volvo',
              'Scania',
              'Mercedes-Benz',
            ].map((brand, index) => (
              <div
                key={index}
                className="px-6 py-3 bg-background rounded-lg border font-medium text-muted-foreground"
              >
                {brand}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
