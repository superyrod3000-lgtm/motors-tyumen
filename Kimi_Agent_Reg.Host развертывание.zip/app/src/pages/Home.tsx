import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { services, faqItems } from '@/data/services';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Wrench,
  Shield,
  Users,
  Settings,
  ArrowRight,
  Phone,
  Calendar,
  CheckCircle,
} from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Гарантия на работы',
    description: 'Предоставляем гарантию на все виды выполненных работ до 12 месяцев',
  },
  {
    icon: Users,
    title: 'Опытные мастера',
    description: 'Наши специалисты имеют более 15 лет опыта в ремонте грузовой техники',
  },
  {
    icon: Settings,
    title: 'Современное оборудование',
    description: 'Используем профессиональное диагностическое и ремонтное оборудование',
  },
];

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-background py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge variant="secondary" className="text-sm">
                Профессиональный грузовой сервис в Тюмени
              </Badge>
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Ремонт грузовых
                <span className="text-primary block">автомобилей</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Специализируемся на ремонте двигателей и топливной системы. 
                Качественно, быстро, с гарантией. Работаем со всеми марками 
                отечественной и китайской техники.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/zapis">
                  <Button size="lg" className="gap-2">
                    <Calendar className="h-4 w-4" />
                    Записаться на ремонт
                  </Button>
                </Link>
                <a href="tel:+79222652920">
                  <Button size="lg" variant="outline" className="gap-2">
                    <Phone className="h-4 w-4" />
                    Позвонить
                  </Button>
                </a>
              </div>
            </div>
            <div className="relative hidden lg:block">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl transform rotate-3" />
              <div className="relative bg-muted rounded-3xl overflow-hidden aspect-[4/3] flex items-center justify-center">
                <Wrench className="h-32 w-32 text-primary/30" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex flex-col items-center text-center p-6"
              >
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gap-4">
            <div>
              <h2 className="text-3xl font-bold mb-4">Наши услуги</h2>
              <p className="text-muted-foreground max-w-xl">
                Полный спектр услуг по ремонту и обслуживанию грузовых автомобилей
              </p>
            </div>
            <Link to="/uslugi">
              <Button variant="outline" className="gap-2">
                Все услуги
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <Link key={service.id} to={`/uslugi/${service.slug}`}>
                <Card className="h-full hover:shadow-lg transition-shadow group">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                      <Wrench className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                    <p className="text-muted-foreground text-sm mb-4">
                      {service.shortDescription}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-primary font-semibold">
                        от {service.priceFrom.toLocaleString('ru-RU')} ₽
                      </span>
                      <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                Почему выбирают нас?
              </h2>
              <p className="text-muted-foreground mb-8">
                Мы — команда профессионалов с многолетним опытом работы 
                в сфере ремонта грузовой техники. Наши преимущества:
              </p>
              <div className="space-y-4">
                {[
                  'Более 15 лет опыта в ремонте грузовых автомобилей',
                  'Современное диагностическое оборудование',
                  'Использование оригинальных запчастей',
                  'Гарантия на все виды работ до 12 месяцев',
                  'Прозрачное ценообразование без скрытых платежей',
                  'Удобное расположение сервиса в Тюмени',
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl transform -rotate-3" />
              <div className="relative bg-muted rounded-3xl overflow-hidden aspect-square flex items-center justify-center">
                <Shield className="h-40 w-40 text-primary/30" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-4">
              Часто задаваемые вопросы
            </h2>
            <p className="text-muted-foreground text-center mb-12">
              Ответы на популярные вопросы о нашем сервисе
            </p>
            <Accordion type="single" collapsible className="w-full">
              {faqItems.map((item, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">
              Нужна консультация?
            </h2>
            <p className="text-primary-foreground/80 mb-8 text-lg">
              Позвоните нам или оставьте заявку — мы свяжемся с вами 
              в течение 15 минут
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/zapis">
                <Button size="lg" variant="secondary" className="gap-2">
                  <Calendar className="h-4 w-4" />
                  Записаться онлайн
                </Button>
              </Link>
              <a href="tel:+79222652920">
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 border-primary-foreground/30 hover:bg-primary-foreground/10"
                >
                  <Phone className="h-4 w-4" />
                  Позвонить
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
