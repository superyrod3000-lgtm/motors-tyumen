import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Wrench, Home, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-lg mx-auto text-center">
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-8">
            <Wrench className="h-12 w-12 text-primary" />
          </div>
          <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
          <h2 className="text-2xl font-bold mb-4">Страница не найдена</h2>
          <p className="text-muted-foreground mb-8">
            К сожалению, запрашиваемая страница не существует или была перемещена. 
            Возможно, вы ввели неправильный адрес или страница была удалена.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/">
              <Button className="gap-2">
                <Home className="h-4 w-4" />
                На главную
              </Button>
            </Link>
            <button onClick={() => window.history.back()}>
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Назад
              </Button>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
