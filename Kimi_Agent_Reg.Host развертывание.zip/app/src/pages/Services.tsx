import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { services } from '@/data/services';
import { Wrench, ArrowRight, CheckCircle } from 'lucide-react';

export default function Services() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              Услуги
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Все услуги нашего сервиса
            </h1>
            <p className="text-lg text-muted-foreground">
              Полный спектр услуг по ремонту и обслуживанию грузовых автомобилей. 
              От диагностики до капитального ремонта двигателя.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <Card key={service.id} className="h-full hover:shadow-lg transition-shadow group">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <Wrench className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    {service.shortDescription}
                  </p>
                  <div className="space-y-2 mb-4">
                    {service.features.slice(0, 3).map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t">
                    <span className="text-primary font-semibold">
                      от {service.priceFrom.toLocaleString('ru-RU')} ₽
                    </span>
                    <Link to={`/uslugi/${service.slug}`}>
                      <Button variant="ghost" size="sm" className="gap-1">
                        Подробнее
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Как мы работаем</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Простой и прозрачный процесс ремонта вашего автомобиля
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Заявка',
                description: 'Оставьте заявку на сайте или позвоните нам по телефону',
              },
              {
                step: '02',
                title: 'Диагностика',
                description: 'Проводим бесплатную диагностику и составляем смету',
              },
              {
                step: '03',
                title: 'Ремонт',
                description: 'Выполняем ремонт с использованием качественных запчастей',
              },
              {
                step: '04',
                title: 'Гарантия',
                description: 'Выдаём документы с гарантией на выполненные работы',
              },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-primary/20 mb-4">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-2xl p-8 lg:p-12 text-primary-foreground">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">
                Не нашли нужную услугу?
              </h2>
              <p className="text-primary-foreground/80 mb-8">
                Свяжитесь с нами — мы проконсультируем по любым вопросам 
                ремонта грузовых автомобилей
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/kontakty">
                  <Button variant="secondary" size="lg">
                    Связаться с нами
                  </Button>
                </Link>
                <a href="tel:+79222652920">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-primary-foreground/30 hover:bg-primary-foreground/10"
                  >
                    +7 (922) 265-29-20
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
