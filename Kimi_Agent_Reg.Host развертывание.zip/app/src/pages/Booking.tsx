import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { services } from '@/data/services';
import { Calendar, Clock, CheckCircle, Car, User, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

export default function Booking() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success('Заявка успешно отправлена! Мы свяжемся с вами в течение 15 минут.');
  };

  if (submitted) {
    return (
      <div className="flex flex-col">
        <section className="py-20 lg:py-32">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="max-w-lg mx-auto">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="h-10 w-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold mb-4">
                  Заявка успешно отправлена!
                </h2>
                <p className="text-muted-foreground mb-6">
                  Спасибо за обращение! Наш менеджер свяжется с вами 
                  в течение 15 минут для уточнения деталей и согласования 
                  времени визита.
                </p>
                <div className="bg-muted rounded-lg p-4 mb-6">
                  <p className="text-sm text-muted-foreground">
                    Если у вас срочный вопрос, позвоните нам:
                  </p>
                  <a
                    href="tel:+79222652920"
                    className="text-lg font-semibold text-primary hover:underline"
                  >
                    +7 (922) 265-29-20
                  </a>
                </div>
                <Button onClick={() => setSubmitted(false)} variant="outline">
                  Отправить ещё одну заявку
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              Запись онлайн
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Записаться на ремонт
            </h1>
            <p className="text-lg text-muted-foreground">
              Заполните форму ниже — мы свяжемся с вами в течение 15 минут 
              для уточнения деталей и согласования времени
            </p>
          </div>
        </div>
      </section>

      {/* Form */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardContent className="p-6 lg:p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Info */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <h3 className="font-semibold">Контактная информация</h3>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">
                          Ваше имя <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="name"
                          placeholder="Иван Иванов"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">
                          Телефон <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+7 (___) ___-__-__"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Vehicle Info */}
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Car className="h-4 w-4 text-primary" />
                      </div>
                      <h3 className="font-semibold">Информация об автомобиле</h3>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="brand">Марка автомобиля</Label>
                        <Input
                          id="brand"
                          placeholder="КамАЗ, Howo, ГАЗ..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="model">Модель</Label>
                        <Input
                          id="model"
                          placeholder="65115, A7, Next..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Service Selection */}
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <MessageSquare className="h-4 w-4 text-primary" />
                      </div>
                      <h3 className="font-semibold">Выбор услуги</h3>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="service">Услуга</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите услугу" />
                        </SelectTrigger>
                        <SelectContent>
                          {services.map((service) => (
                            <SelectItem key={service.id} value={service.slug}>
                              {service.title}
                            </SelectItem>
                          ))}
                          <SelectItem value="other">Другое (указать в комментарии)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description">Описание проблемы</Label>
                      <Textarea
                        id="description"
                        placeholder="Опишите симптомы неисправности или необходимые работы..."
                        rows={4}
                      />
                    </div>
                  </div>

                  {/* Date & Time */}
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Calendar className="h-4 w-4 text-primary" />
                      </div>
                      <h3 className="font-semibold">Предпочтительное время</h3>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="date">Дата</Label>
                        <Input id="date" type="date" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="time">Время</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Выберите время" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="09:00">09:00</SelectItem>
                            <SelectItem value="10:00">10:00</SelectItem>
                            <SelectItem value="11:00">11:00</SelectItem>
                            <SelectItem value="12:00">12:00</SelectItem>
                            <SelectItem value="13:00">13:00</SelectItem>
                            <SelectItem value="14:00">14:00</SelectItem>
                            <SelectItem value="15:00">15:00</SelectItem>
                            <SelectItem value="16:00">16:00</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Submit */}
                  <div className="pt-4 border-t">
                    <Button type="submit" size="lg" className="w-full gap-2">
                      <Clock className="h-4 w-4" />
                      Отправить заявку
                    </Button>
                    <p className="text-xs text-muted-foreground text-center mt-4">
                      Нажимая кнопку, вы соглашаетесь с{' '}
                      <a href="/privacy" className="underline hover:text-primary">
                        политикой конфиденциальности
                      </a>{' '}
                      и{' '}
                      <a href="/consent" className="underline hover:text-primary">
                        согласием на обработку данных
                      </a>
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Info */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Быстрый ответ</h3>
                <p className="text-sm text-muted-foreground">
                  Мы свяжемся с вами в течение 15 минут после получения заявки
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Удобное время</h3>
                <p className="text-sm text-muted-foreground">
                  Согласуем время визита, которое подходит именно вам
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Бесплатная диагностика</h3>
                <p className="text-sm text-muted-foreground">
                  При первом визите диагностика всех систем бесплатно
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
