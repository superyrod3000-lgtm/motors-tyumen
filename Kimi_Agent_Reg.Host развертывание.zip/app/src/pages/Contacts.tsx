import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Phone,
  MapPin,
  Clock,
  Mail,
  ExternalLink,
  Send,
} from 'lucide-react';

export default function Contacts() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-background py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              Контакты
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Свяжитесь с нами
            </h1>
            <p className="text-lg text-muted-foreground">
              Мы всегда рады ответить на ваши вопросы и помочь с ремонтом 
              вашего грузового автомобиля
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info & Form */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-2xl font-bold mb-8">Контактная информация</h2>
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">Телефоны</h3>
                        <div className="space-y-2">
                          <a
                            href="tel:+79222652920"
                            className="block text-muted-foreground hover:text-primary transition-colors"
                          >
                            +7 (922) 265-29-20
                          </a>
                          <a
                            href="tel:+73452981270"
                            className="block text-muted-foreground hover:text-primary transition-colors"
                          >
                            +7 (3452) 98-12-70
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">Адрес</h3>
                        <p className="text-muted-foreground">
                          г. Тюмень, ул. Щербакова, 170 ст6
                        </p>
                        <div className="flex gap-3 mt-4">
                          <a
                            href="https://yandex.ru/maps/-/CDXW5Z~n"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#FFD700] text-black rounded-md hover:bg-[#FFC700] transition-colors"
                          >
                            Яндекс Карты
                            <ExternalLink className="h-3 w-3" />
                          </a>
                          <a
                            href="https://2gis.ru/tyumen/firm/1830115629869353"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#7CB342] text-white rounded-md hover:bg-[#6A9E3A] transition-colors"
                          >
                            2GIS
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Clock className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">График работы</h3>
                        <div className="space-y-1 text-muted-foreground">
                          <div className="flex justify-between">
                            <span>Понедельник — Пятница</span>
                            <span className="font-medium">09:00 — 17:00</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Суббота</span>
                            <span className="font-medium">Выходной</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Воскресенье</span>
                            <span className="font-medium">Выходной</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mt-3">
                          Возможен приём по предварительной договорённости 
                          вне рабочего времени
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">Email</h3>
                        <a
                          href="mailto:info@motors-tyumen.ru"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          info@motors-tyumen.ru
                        </a>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold mb-8">Напишите нам</h2>
              <Card>
                <CardContent className="p-6">
                  <form className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Ваше имя</Label>
                        <Input id="name" placeholder="Иван Иванов" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Телефон</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+7 (___) ___-__-__"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="example@mail.ru"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">Тема</Label>
                      <Input
                        id="subject"
                        placeholder="Вопрос о ремонте двигателя"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message">Сообщение</Label>
                      <Textarea
                        id="message"
                        placeholder="Опишите ваш вопрос или проблему..."
                        rows={5}
                      />
                    </div>
                    <Button type="submit" className="w-full gap-2">
                      <Send className="h-4 w-4" />
                      Отправить сообщение
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      Нажимая кнопку, вы соглашаетесь с{' '}
                      <a href="/privacy" className="underline hover:text-primary">
                        политикой конфиденциальности
                      </a>
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-8 text-center">Мы на карте</h2>
          <Card>
            <CardContent className="p-0">
              <div className="aspect-[16/9] bg-muted flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-primary/30 mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    Интерактивная карта будет загружена здесь
                  </p>
                  <div className="flex gap-3 justify-center mt-4">
                    <a
                      href="https://yandex.ru/maps/-/CDXW5Z~n"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm">
                        Открыть в Яндекс.Картах
                      </Button>
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
