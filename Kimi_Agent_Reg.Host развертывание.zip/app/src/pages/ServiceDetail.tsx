import { useParams, Link, Navigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getServiceBySlug, services } from '@/data/services';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import { Wrench, ArrowLeft, CheckCircle, Calendar, Phone } from 'lucide-react';

export default function ServiceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const service = getServiceBySlug(slug || '');

  if (!service) {
    return <Navigate to="/uslugi" replace />;
  }

  const otherServices = services.filter((s) => s.id !== service.id).slice(0, 3);

  return (
    <div className="flex flex-col">
      {/* Breadcrumbs */}
      <div className="bg-muted/30 py-4">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Главная</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/uslugi">Услуги</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{service.title}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Hero */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <Link to="/uslugi">
                <Button variant="ghost" size="sm" className="mb-6 gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Назад к услугам
                </Button>
              </Link>
              <Badge variant="secondary" className="mb-4">
                от {service.priceFrom.toLocaleString('ru-RU')} ₽
              </Badge>
              <h1 className="text-3xl lg:text-4xl font-bold mb-6">
                {service.title}
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                {service.fullDescription}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/zapis">
                  <Button size="lg" className="gap-2">
                    <Calendar className="h-4 w-4" />
                    Записаться
                  </Button>
                </Link>
                <a href="tel:+79222652920">
                  <Button size="lg" variant="outline" className="gap-2">
                    <Phone className="h-4 w-4" />
                    Позвонить
                  </Button>
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl transform rotate-3" />
              <div className="relative bg-muted rounded-3xl overflow-hidden aspect-[4/3] flex items-center justify-center">
                <Wrench className="h-32 w-32 text-primary/30" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-bold mb-6">Что входит в услугу</h2>
              <div className="space-y-3">
                {service.features.map((feature, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-4 bg-background rounded-lg"
                  >
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-6">Преимущества</h2>
              <div className="space-y-3">
                {service.benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-4 bg-background rounded-lg"
                  >
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Other Services */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-8">Другие услуги</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {otherServices.map((s) => (
              <Link key={s.id} to={`/uslugi/${s.slug}`}>
                <Card className="h-full hover:shadow-lg transition-shadow group">
                  <CardContent className="p-6">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                      <Wrench className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{s.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {s.shortDescription}
                    </p>
                    <div className="mt-4 text-primary font-medium">
                      от {s.priceFrom.toLocaleString('ru-RU')} ₽
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-2xl p-8 lg:p-12 text-primary-foreground">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">
                Запишитесь на {service.title.toLowerCase()}
              </h2>
              <p className="text-primary-foreground/80 mb-8">
                Оставьте заявку — мы свяжемся с вами в течение 15 минут 
                для уточнения деталей и записи на удобное время
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/zapis">
                  <Button variant="secondary" size="lg" className="gap-2">
                    <Calendar className="h-4 w-4" />
                    Записаться онлайн
                  </Button>
                </Link>
                <a href="tel:+79222652920">
                  <Button
                    variant="outline"
                    size="lg"
                    className="gap-2 border-primary-foreground/30 hover:bg-primary-foreground/10"
                  >
                    <Phone className="h-4 w-4" />
                    Позвонить
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
